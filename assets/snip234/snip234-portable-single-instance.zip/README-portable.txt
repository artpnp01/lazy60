snip234 portable

Run:
1. Double-click snip234.exe.
2. Click the tray icon to open settings.
3. Use the hotkey to start snipping.

Default hotkey:
Ctrl + Shift + J

Exit:
Right-click the tray icon, then choose Exit App.

Notes:
- No installer is required.
- Settings are stored under the current Windows user profile.
- Launch on boot uses the current user's startup registry entry.
